/****************************************************************************/
/*  projekt:     RMOS3-PCI                                                  */
/****************************************************************************/
/*  modul:       Define.h                                                   */
/*  description: global defines                                             */
/*  functions:   <none>                                                     */
/*  author:                                                                 */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version    change                                 */
/****************************************************************************/


/****************************************************************************/
/*  defines                                                                 */
/****************************************************************************/

  /* defines for whole project */
    #define xyz_DEVICE_ID	  	0x0000
    #define xyz_VENDOR_ID	  	0x0000
	#define xyz_SUB_VENDOR_ID	0x0000
	#define xyz_SUBSYSTEM_ID	0x0000

    #define MAX_NUM_OF_FUNCTIONS 10

	typedef struct {
		int 	* pxyz;
		uint	chainID;
	} T_CALLER;

