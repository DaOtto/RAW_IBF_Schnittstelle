/****************************************************************************/
/*  projekt:     RMOS3-PCI Example                                          */
/****************************************************************************/
/*  modul:       Handler.c                                                  */
/*  description:                                                            */
/*  functions:                                                              */
/*  author:                                                                 */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version   change                                  */
/****************************************************************************/


/****************************************************************************/
/*  includes                                                                */
/****************************************************************************/

/* includes from outside the project */
  #include <stdio.h>
  #include <rmapi.h>
  #include "Define.h"
  #include "rmpci.h"

/* declarations from inside the project */
  #include "Global.h"


/****************************************************************************/
/*  declarations                                                            */
/****************************************************************************/
int _FIXED _FAR ISR_I_Handler(T_CALLER *);
int _FIXED _FAR ISR_S_Handler(T_CALLER *);
int _FIXED _FAR ISR_S_Handler_LL(T_CALLER *);



/****************************************************************************/
/*  function:    ISR_I_Handler		                                        */
/*  description:                                                            */
/*  input:       Pointer from context                                       */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR ISR_I_Handler(T_CALLER *Caller)
{
	int IntReg;

	/* Read the Interrupt-Register											*/
	/*	IntReg = *(Caller->pEA221+INTERRUPT_REG);							*/

  	/* handle the interrupt, if competent for it 							*/
	if ( IntReg != 0 )
		return (1);			/* handle the interrupt, in the S-handler		*/
	else
		return (2);			/* not competent of this interruptrequest		*/
}



/****************************************************************************/
/*  function:    ISR_S_Handler                                              */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR ISR_S_Handler (T_CALLER *Caller)
{
	/* to do */

    return (RM_OK);

}



