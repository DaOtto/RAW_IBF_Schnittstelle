/****************************************************************************/
/*  projekt: RMOS3-PCI   example  example  example  example  example        */
/****************************************************************************/
/*  modul:                                                                  */
/*  description:                                                            */
/*  functions:                                                              */
/*  author:                                                                 */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version   change                                  */
/****************************************************************************/


/****************************************************************************/
/*  includes                                                                */
/****************************************************************************/


  #include <stdio.h>
  #include <stdlib.h>
  #include <rmapi.h> 

  #include "rmpci.h"
  #include "define.h"
  #include "handler.h"
  #include "global.h"




/****************************************************************************/
/*  declarations                                                            */
/****************************************************************************/
int _FAR	main(void);
void 		HandleError(int, char *);



int			IntMerker;




/****************************************************************************/
/*  function:    main                                                       */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2000, confidential, all rights reserved        */
/****************************************************************************/
int _FAR main(void) 
{

  /* variables */
    PCI_CONFIG_SPACE 	ConfigSpace[MAX_NUM_OF_FUNCTIONS];
    int    				error, i;
	ushort				numOfFunctions;

	T_CALLER			Caller[MAX_NUM_OF_FUNCTIONS];



  /* detect all functions in the whole pci system, whose vendor and */
  /* device ids correspond to a xyz-PCI board	                */
    error = RmPciSearchSubFunction(xyz_VENDOR_ID, xyz_DEVICE_ID, xyz_SUB_VENDOR_ID, xyz_SUBSYSTEM_ID, 
							    ConfigSpace, MAX_NUM_OF_FUNCTIONS, &numOfFunctions);

	
	/* PCI-device found												*/
	if (numOfFunctions !=0 )
	{
	   	/* Share-Interrupt Client Initialisieren 					*/
	    error = RmInitShIntClient();
		
		for (i=0; i<numOfFunctions;i++)
		{
			/* I- und S-Handler einh�ngen 							*/
		    error = RmSetShIntISHandler2(IRQ(ConfigSpace[i].IntLine),
		   								 ISR_I_Handler, ISR_S_Handler, &Caller[i], &Caller[i].chainID);
		}
		

		
		/* to do ...  */
	
	}
	else
	{
		exit(RM_OK);
	}

}
