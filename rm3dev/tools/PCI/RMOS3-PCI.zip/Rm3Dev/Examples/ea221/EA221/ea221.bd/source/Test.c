/****************************************************************************/
/*  projekt: RMOS3-PCI   example  example  example  example  example        */
/****************************************************************************/
/*  modul:                                                                  */
/*  description:                                                            */
/*  functions:                                                              */
/*  author:                                                                 */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version   change                                  */
/*                        0001      original issue                          */
/****************************************************************************/


/****************************************************************************/
/*  includes                                                                */
/****************************************************************************/


  #include <stdio.h>
  #include <stdlib.h>
  #include <rmapi.h> 

  #include "rmpci.h"
  #include "define.h"
  #include "handler.h"
  #include "global.h"
  #include "EA221.h"




/****************************************************************************/
/*  declarations                                                            */
/****************************************************************************/
int _FAR	main(void);
void 		HandleError(int, char *);



int			IntMerker;




/****************************************************************************/
/*  function:    DisplayPci                                                 */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2000, confidential, all rights reserved        */
/****************************************************************************/
void DisplayPci(ushort numOfFunctions, PCI_CONFIG_SPACE pciConfigSpace[]) {

  /* variables */
    ushort i;

  /* display certain elements of given configuration spaces */
    printf("Bus    Device   Function   InterruptLine   BaseAddr0   BaseAddr 1\n");
    for (i = 0; i < numOfFunctions; i++) {
      printf("0x%2.2x   0x%.2.2x     0x%1.1x        0x%2.2x            0x%8.8x  0x%.8.8x\n",
        pciConfigSpace[i].PciBusNum, pciConfigSpace[i].PciDeviceNum,
        pciConfigSpace[i].PciFunctionNum, pciConfigSpace[i].IntLine,
        pciConfigSpace[i].BaseAdr0, pciConfigSpace[i].BaseAdr1);
    }

  /* end function */
    return;

}





/****************************************************************************/
/*  function:    HandleError                                                */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
void HandleError(int error, char *caller) {

  /* check, if error occured, and handle it by leaving task */
    if (error != RM_OK) {
      printf(caller);
      printf(": Error %d\n", error);
      exit(error);
    }

  /* end function */
    return;

}





/****************************************************************************/
/*  function:    main                                                       */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2000, confidential, all rights reserved        */
/****************************************************************************/
int _FAR main(void) 
{

  /* variables */
    PCI_CONFIG_SPACE 	EA221ConfigSpace[MAX_NUM_OF_EA221_FUNCTIONS];
    int    				error, i;
	ushort				numOfEA221Functions;

	T_CALLER			Caller[MAX_NUM_OF_EA221_FUNCTIONS];


	for (i=0; i<MAX_NUM_OF_EA221_FUNCTIONS;i++)
	{
		Caller[i].IntMerker = FALSE;
		Caller[i].IntMerker_2 = FALSE;
		Caller[i].IntMerker_LL = FALSE;
	}



  /* detect all functions in the whole pci system, whose vendor and */
  /* device ids correspond to a EEA221 PCI board	                */
    error = RmPciSearchSubFunction(EA221_VENDOR_ID, EA221_DEVICE_ID, EA221_SUB_VENDOR_ID, EA221_SUBSYSTEM_ID, 
							    EA221ConfigSpace, MAX_NUM_OF_EA221_FUNCTIONS, &numOfEA221Functions);
    HandleError(error, "SearchEEA221");

	/* displays mayor config-register */
   	DisplayPci(numOfEA221Functions, EA221ConfigSpace);

	
	/* EA221 found													*/
	if (numOfEA221Functions !=0 )
	{
	   	/* Share-Interrupt Client Initialisieren 					*/
	    error = RmInitShIntClient();
	    HandleError(error, "RmInitShIntClient");
		
		for (i=0; i<numOfEA221Functions;i++)
		{
			/* EA221 Initialisierung 									*/
			if ( ( error = TestInitEA221(&EA221ConfigSpace[i], &Caller[i].pEA221) ) != RM_OK)
			    HandleError(error, "TestInitEA221");
	
			/* EA221 Konfigurierung 									*/
			if ( error = TestKonfigEA221(Caller[i].pEA221) != RM_OK)
			    HandleError(error, "TestKonfigEA221");
	
			/* I- und S-Handler einh�ngen 								*/
			if (i==0)
			{
			    error = RmSetShIntISHandler2(IRQ(EA221ConfigSpace[i].IntLine),
			   								 ISR_EA221_I_Handler, ISR_EA221_S_Handler_LL, &Caller[i], &Caller[i].chainID);
			    HandleError(error, "RmSetShIntISHandler2");
			}
			else if (i==1)
			{
			    error = RmSetShIntISHandler2(IRQ(EA221ConfigSpace[i].IntLine),
			   								 ISR_EA221_I_Handler, ISR_EA221_S_Handler_2, &Caller[i], &Caller[i].chainID);
			    HandleError(error, "RmSetShIntISHandler2");
			}

			else if (i==2)
			{
			    error = RmSetShIntISHandler2(IRQ(EA221ConfigSpace[i].IntLine),
			   								 ISR_EA221_I_Handler, ISR_EA221_S_Handler, &Caller[i], &Caller[i].chainID);
			    HandleError(error, "RmSetShIntISHandler2");
			}
		
			/* Test starten 											*/
			if ( error = TestStartEA221(Caller[i].pEA221) != RM_OK)
			    HandleError(error, "TestStartEA221");

			RmPauseTask(500);

		}
		

		/* test the EA221 modul */
		while (1)
		{
			/* check all devices */
			for ( i=0; i<numOfEA221Functions;i++)
 		    {
				/* check interrupt notice */
   				if (Caller[i].IntMerker == TRUE)
				{
					/* there was an interrupt */
					Caller[i].IntMerker = FALSE;
					RmPauseTask(150);

					/* is the input a high level ? */
					if ( ( *(Caller[i].pEA221) & 0x00010000) != 0 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						RmPauseTask(150);
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH;
					}
					else
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH;
				}


				/* check interrupt notice */
   				if (Caller[i].IntMerker_2 == TRUE)
				{
					/* there was an interrupt */
					Caller[i].IntMerker_2 = FALSE;

					
					/* is the input a high level ? */
					if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00010000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_15;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00020000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_0;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00040000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_1;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00080000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_2;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00100000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_3;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00200000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_4;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00400000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_5;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00800000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_6;
					}
					/* is the input a high level ? */
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x01000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_7;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x02000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_8;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x04000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_9;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x08000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_10;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x10000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_11;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x20000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_12;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x40000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_13;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x80000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_14;
					}
					else
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH;
					
					
					
				}



				/* check interrupt notice from Lauflicht-Device*/
   				if (Caller[i].IntMerker_LL == TRUE)
				{
					/* there was an interrupt */
					Caller[i].IntMerker_LL = FALSE;

					/* is the input a high level ? */
					if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00010000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_1;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00020000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_2;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00040000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_3;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00080000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_4;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00100000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_5;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00200000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_6;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00400000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_7;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x00800000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_8;
					}
					/* is the input a high level ? */
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x01000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_9;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x02000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_10;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x04000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_11;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x08000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_12;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x10000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_13;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x20000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_14;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x40000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_15;
					}
					else if ( ( *(Caller[i].pEA221) & 0xffff0000) == 0x80000000 )
					{
						/* reset the output */
						*( Caller[i].pEA221) = VAL_E_A_LOW;
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH_0;
					}
					else
						/* set the output to a high level */
						*( Caller[i].pEA221 ) = VAL_E_A_HIGH;
				}

			}	/* next device */
		}	
		
	
	    exit(RM_OK);
	}
	else
	{
		printf(" EA221_BSP> No EA221-module found!\r\n");
		exit(RM_OK);
	}

}
