/****************************************************************************/
/*  projekt:     RMOS3-PCI Example                                          */
/****************************************************************************/
/*  modul:       Handler.c                                                  */
/*  description:                                                            */
/*  functions:                                                              */
/*  author:                                                                 */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version   change                                  */
/*  06.08.01               0001      original issue                         */
/****************************************************************************/


/****************************************************************************/
/*  includes                                                                */
/****************************************************************************/

/* includes from outside the project */
  #include <stdio.h>
  #include <rmapi.h>
  #include "Define.h"
  #include "rmpci.h"

/* declarations from inside the project */
  #include "Global.h"
  #include "EA221.h"


/****************************************************************************/
/*  declarations                                                            */
/****************************************************************************/
int _FIXED _FAR ISR_EA221_I_Handler(T_CALLER *);
int _FIXED _FAR ISR_EA221_S_Handler(T_CALLER *);
int _FIXED _FAR ISR_EA221_S_Handler_LL(T_CALLER *);

int _FIXED _FAR TestInitEA221(PCI_CONFIG_SPACE *, int **);
int _FIXED _FAR TestKonfigEA221(int *);
int _FIXED _FAR TestStartEA221(int *);



/****************************************************************************/
/*  function:    TestInitEA221   		                                    */
/*  description:                                                            */
/*  input:       PCI_CONFIG_SPACE                                           */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR TestInitEA221( PCI_CONFIG_SPACE *Config, int **pEA221) 
{
	selector sel;
	int error;

	/* read from the Configspace of the EA221 the basaddress 				*/
	if ( Config->BaseAdr0 != 0)
	{
		/* modifies the flat-address in a seg-address 						*/
		error = RmCreateDescriptor ((ulong)Config->BaseAdr0, EA221_ADR_RANGE, &sel);
		if ( error != RM_OK)
			return (error);

  		/* get a pointer to the start address of the base-address 			*/
  		*pEA221 = buildptr (sel, 0);
		
		return (RM_OK);
	}
	else
		return (-1);
}




					   
/****************************************************************************/
/*  function:    TestKonfigEA221   		                                    */
/*  description:                                                            */
/*  input:       PCI_CONFIG_SPACE                                           */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR TestKonfigEA221(int *pStartAdresse ) 
{
	/* Eingangsmodus-Register:	 											*/
	*(pStartAdresse+EINGANGSMOD_REG) = VAL_EINGANGSMOD_REG;

	/* Konfigurations-Register 												*/
	*(pStartAdresse+KONFIG_REG) = VAL_KONFIG_REG_REG;

	/* INTERRUPT-MASKEN-Register 											*/
	*(pStartAdresse+INTERRUPT_MASK_REG) = VAL_INTERRUPT_MASK_REG;

	/* LED-Register 0 														*/
	*(pStartAdresse+LED_0_REG) = VAL_LED_0_REG;

	/* LED-Register 1 */
	*(pStartAdresse+LED_1_REG) = VAL_LED_1_REG;

	return (RM_OK);


}



/****************************************************************************/
/*  function:    TestStartEA221   		                                    */
/*  description:                                                            */
/*  input:       PCI_CONFIG_SPACE                                           */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR TestStartEA221( int *pStartAdresse) 
{

	/* check i/o -register */
	if ( *(pStartAdresse) != 0 )
	{
		/* reset output 0 to low level	*/
		*(pStartAdresse) = VAL_E_A_LOW;
		RmPauseTask(500);
	}

	/* set output 0 to high level	*/
	*(pStartAdresse) = VAL_E_A_HIGH;

	return (RM_OK);

}







/****************************************************************************/
/*  function:    ISR_EEA221_I_Handler                                       */
/*  description:                                                            */
/*  input:       Pointer from context = startaddress of the EA221           */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR ISR_EA221_I_Handler(T_CALLER *Caller)
{
	int IntReg;

	/* Read the Interrupt-Register of the EA221								*/
	IntReg = *(Caller->pEA221+INTERRUPT_REG);

  	/* handle the interrupt, if competent for it 							*/
	if ( IntReg != 0 )
		return (1);			/* handle the interrupt, in the S-handler		*/
	else
		return (2);			/* not competent of this interruptrequest		*/
}



/****************************************************************************/
/*  function:    ISR_EEA221_S_Handler                                       */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR ISR_EA221_S_Handler (T_CALLER *Caller)
{
	/* set the mark */
	Caller->IntMerker = TRUE;

    return (RM_OK);

}


/****************************************************************************/
/*  function:    ISR_EEA221_S_Handler                                       */
/*  description:                                                            */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR ISR_EA221_S_Handler_2 (T_CALLER *Caller)
{
	/* set the mark */
	Caller->IntMerker_2 = TRUE;

    return (RM_OK);

}





/****************************************************************************/
/*  function:    ISR_EEA221_S_Handler_LL                                    */
/*  description: Lauflicht                                                  */
/*  input:                                                                  */
/*                                                                          */
/*  output:                                                                 */
/*  return:                                                                 */
/*  copyright:   (c) siemens 2001, confidential, all rights reserved        */
/****************************************************************************/
int _FIXED _FAR ISR_EA221_S_Handler_LL (T_CALLER *Caller)
{
		
	/* set the mark */
	Caller->IntMerker_LL = TRUE;

    return (RM_OK);

}


