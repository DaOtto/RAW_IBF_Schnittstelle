/****************************************************************************/
/*  projekt:     RMOS3-PCI/Test                                             */
/****************************************************************************/
/*  modul:       Handler.h                                                  */
/*  description:                                                            */
/*  functions:                                                              */
/*  author:      he4862                                                     */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2000, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version   change                                  */
/*               he4862   0001      original issue                          */
/****************************************************************************/


/****************************************************************************/
/*  declarations                                                            */
/****************************************************************************/
extern int _FIXED _FAR ISR_EA221_I_Handler(void *);
extern int _FIXED _FAR ISR_EA221_S_Handler(void *);
extern int _FIXED _FAR ISR_EA221_S_Handler_2(void *);
extern int _FIXED _FAR ISR_EA221_S_Handler_LL(void *);

int _FIXED _FAR TestInitEA221(PCI_CONFIG_SPACE *, int **);
int _FIXED _FAR TestKonfigEA221(int *);
int _FIXED _FAR TestStartEA221(int *);

