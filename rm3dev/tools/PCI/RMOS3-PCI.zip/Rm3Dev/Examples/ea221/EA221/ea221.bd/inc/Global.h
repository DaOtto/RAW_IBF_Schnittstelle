/****************************************************************************/
/*  projekt:     RMOS3-PCI/Test                                             */
/****************************************************************************/
/*  modul:       Global.h                                                   */
/*  description: global variables                                           */
/*  functions:   <none>                                                     */
/*  author:      he4862                                                     */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2000, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version    change                                 */
/*               he4862   V1.00.00   original issue                         */
/****************************************************************************/


/****************************************************************************/
/*  declarations                                                            */
/****************************************************************************/

  /* identity string */
    extern const char idstr[];
    extern uint     chainID;
	extern int		IntMerker;

