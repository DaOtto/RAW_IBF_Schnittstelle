#define EA221_ADR_RANGE		64

#define	E_A_REG				0x0
#define EINGANGSMOD_REG		0x1
#define KONFIG_REG			0x2
#define	INTERRUPT_REG		0x6
#define INTERRUPT_MASK_REG	0x7
#define	LED_0_REG			0x0A
#define	LED_1_REG			0x0B


/* Eingangsmod = steigende Flanke E0	*/
#define	VAL_EINGANGSMOD_REG		0xFF00FF00

/* Konfig = normal 						*/
#define	VAL_KONFIG_REG_REG		0x00000000

/* Interrupt-Maske = alle maskiert, bis	*/
/* auf Eingangsinterrupt MEINT0 		*/
#define	VAL_INTERRUPT_MASK_REG	0xFFFF0000

/* Led 0 = Zustand des Ausgangs 0 		*/
#define VAL_LED_0_REG			0x0000FFFF

/* Led 3 = Eingang 0 = High-Pegel		*/
/* Led 4 = Eingang 0 = Low-Pegel		*/
#define VAL_LED_1_REG			0xFFFFFFFF

/* Ein-Ausgangsregister setzen 			*/
#define VAL_E_A_HIGH			0x00001111
#define VAL_E_A_LOW				0x00000000

#define VAL_E_A_HIGH_0			0x00000001
#define VAL_E_A_HIGH_1			0x00000002
#define VAL_E_A_HIGH_2			0x00000004
#define VAL_E_A_HIGH_3			0x00000008
#define VAL_E_A_HIGH_4			0x00000010
#define VAL_E_A_HIGH_5			0x00000020
#define VAL_E_A_HIGH_6			0x00000040
#define VAL_E_A_HIGH_7			0x00000080
#define VAL_E_A_HIGH_8			0x00000100
#define VAL_E_A_HIGH_9			0x00000200
#define VAL_E_A_HIGH_10			0x00000400
#define VAL_E_A_HIGH_11			0x00000800
#define VAL_E_A_HIGH_12			0x00001000
#define VAL_E_A_HIGH_13			0x00002000
#define VAL_E_A_HIGH_14			0x00004000
#define VAL_E_A_HIGH_15			0x00008000

