/****************************************************************************/
/*  projekt:     RMOS3-PCI/Test                                             */
/****************************************************************************/
/*  modul:       Define.h                                                   */
/*  description: global defines                                             */
/*  functions:   <none>                                                     */
/*  author:      he4862                                                     */
/*  date:                                                                   */
/*  version:     V1.00.00                                                   */
/*  copyright:   (c) siemens 2000, confidential, all rights reserved        */
/****************************************************************************/
/*  date         name     version    change                                 */
/*               he4862   V1.00.00   original issue                         */
/****************************************************************************/


/****************************************************************************/
/*  defines                                                                 */
/****************************************************************************/

  /* defines for whole project */
    #define EA221_DEVICE_ID  	0x0300
    #define EA221_VENDOR_ID  	0x10EE
	#define EA221_SUB_VENDOR_ID	0x110A
	#define EA221_SUBSYSTEM_ID	0x4018

    #define MAX_NUM_OF_EA221_FUNCTIONS 10

	typedef struct {
		int 	* pEA221;
		uint	chainID;
		int		IntMerker;
		int		IntMerker_2;
		int		IntMerker_LL;
	} T_CALLER;

